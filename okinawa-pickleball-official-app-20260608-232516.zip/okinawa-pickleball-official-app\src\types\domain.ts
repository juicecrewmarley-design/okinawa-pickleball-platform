export type MemberArea = "south" | "naha" | "central" | "miyako" | "other";

export type Gender = "male" | "female" | "other" | "no_answer";

export type MemberRole = "member" | "admin" | "sponsor";

export type TournamentStatus = "draft" | "open" | "closed" | "finished";

export type RankingCategory = "mens" | "womens" | "mixed" | "overall";

export type MemberProfile = {
  id: string;
  memberId: string;
  fullName: string;
  furigana: string;
  gender: Gender;
  birthDate: string;
  phone: string;
  email: string;
  area: MemberArea;
  role: MemberRole;
  opr: number;
  ranking: number;
};

export type Tournament = {
  id: string;
  title: string;
  description: string;
  venue: string;
  startAt: string;
  entryDeadline: string;
  feeYen: number;
  capacity: number;
  categories: string[];
  status: TournamentStatus;
};

export type TournamentEntry = {
  id: string;
  tournamentId: string;
  memberId: string;
  memberName: string;
  category: string;
  pairOrTeamName: string;
  status: "pending" | "confirmed" | "cancelled";
  createdAt: string;
};

export type RankingRow = {
  rank: number;
  memberId: string;
  fullName: string;
  area: MemberArea;
  points: number;
  wins: number;
};

export type Notice = {
  id: string;
  title: string;
  body: string;
  type: "event" | "tournament" | "practice" | "association";
  publishedAt: string;
};

export type Sponsor = {
  id: string;
  companyName: string;
  description: string;
  websiteUrl: string;
  rank: "platinum" | "gold" | "silver" | "bronze" | "supporter";
  logoLabel: string;
};
