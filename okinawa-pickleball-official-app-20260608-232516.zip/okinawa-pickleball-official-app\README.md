# 沖縄県ピックルボール協会 公式アプリ

会員制度、大会エントリー、OPRポイント、ランキング、お知らせ、協賛企業PRを一元管理するMVPです。

## MVPで実装済みの画面

- 会員登録: 会員IDを自動発行し、Supabase設定済みならAuth登録とプロフィール保存を行います。
- ログイン: 一般会員と管理者ログインの導線を分けています。
- 会員マイページ: QRコード付き会員証、参加履歴、OPR、ランキングを表示します。
- 大会一覧・大会詳細: カテゴリ選択とペア名またはチーム名の入力でエントリーできます。
- 管理者画面: 会員一覧、大会作成フォーム、参加者一覧、試合結果入力、お知らせ投稿、協賛企業登録の初期UIです。
- OPRランキング: 男子、女子、ミックス、総合ランキングのタブ表示です。
- お知らせ・協賛企業: イベント案内とスポンサー掲載ページです。

Supabase未設定でもサンプルデータで画面確認できます。環境変数を設定すると、登録・ログイン・大会エントリーがSupabase向けに動きます。

## ローカルで動かす方法

1. Node.jsをインストールします。
2. このフォルダで依存関係を入れます。

```bash
npm install
```

3. Supabaseを使う場合は、`.env.local.example`をコピーして`.env.local`を作り、値を入れます。

```bash
cp .env.local.example .env.local
```

4. Supabase SQLエディタで`supabase/schema.sql`を実行します。
5. 開発サーバーを起動します。

```bash
npm run dev
```

6. ブラウザで`http://localhost:3000`を開きます。

## Windowsで起動する手順

1. Node.js LTSをインストールします。
   - 公式サイト: https://nodejs.org/
   - インストール後、PowerShellまたはコマンドプロンプトを開き直してください。

2. ZIPを展開します。
   - 例: `C:\Users\naoto\OneDrive\Documents\アプリ作成\okinawa-pickleball-official-app`

3. PowerShellでアプリのフォルダへ移動します。

```powershell
cd "C:\Users\naoto\OneDrive\Documents\アプリ作成\okinawa-pickleball-official-app"
```

4. 初回だけ依存関係をインストールします。

```powershell
npm install
```

5. Supabaseを使う場合は、`.env.local.example`をコピーして`.env.local`を作成します。

```powershell
Copy-Item .env.local.example .env.local
```

`.env.local`に以下を設定してください。

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
NEXT_PUBLIC_ADMIN_EMAILS=admin@example.com
```

Supabaseをまだ設定しない場合でも、サンプルデータで画面プレビューできます。

6. 開発サーバーを起動します。

```powershell
npm run dev
```

7. ブラウザで以下のURLを開きます。

```text
http://localhost:3000
```

起動に成功すると、PowerShellに`Ready`と表示されます。終了するときは、PowerShellで`Ctrl + C`を押してください。

## ZIP配布について

配布用ZIPには、ソースコード、設定ファイル、README、Supabaseスキーマ、画像素材を含めます。`node_modules`、`.next`、キャッシュ、検証用スクリーンショットは含めません。ZIPを展開した後、上記のWindows手順で起動してください。

## 設計資料

- 基本設計: `docs/basic-design.md`
- Supabaseスキーマ: `supabase/schema.sql`

## 管理者権限

Supabase上の`profiles.role`を`admin`にすると管理者扱いです。初回はSupabase SQLエディタで対象ユーザーのroleを変更してください。

```sql
update public.profiles
set role = 'admin'
where email = 'admin@example.com';
```
