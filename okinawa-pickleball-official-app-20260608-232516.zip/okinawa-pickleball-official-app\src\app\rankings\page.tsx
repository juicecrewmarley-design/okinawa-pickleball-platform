"use client";

import { useState } from "react";
import { Trophy } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { RankingTable } from "@/components/RankingTable";
import { rankingLabels } from "@/lib/labels";
import { rankings } from "@/lib/mock-data";
import type { RankingCategory } from "@/types/domain";

const tabs: RankingCategory[] = ["overall", "mens", "womens", "mixed"];

export default function RankingsPage() {
  const [active, setActive] = useState<RankingCategory>("overall");

  return (
    <PageShell
      eyebrow="OPR Ranking"
      title="年間OPRランキング"
      description="参加ポイント、勝利ポイント、順位ポイントを集計し、男子・女子・ミックス・総合のランキングを表示します。"
    >
      <div className="mb-5 flex gap-2 overflow-x-auto rounded-lg border border-ocean-100 bg-white p-2 shadow-soft">
        {tabs.map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setActive(tab)}
            className={`focus-ring inline-flex shrink-0 items-center gap-2 rounded-md px-4 py-3 text-sm font-black ${
              active === tab ? "bg-ink text-white" : "bg-ocean-50 text-ink hover:bg-ocean-100"
            }`}
          >
            <Trophy className="size-4" aria-hidden="true" />
            {rankingLabels[tab]}
          </button>
        ))}
      </div>
      <RankingTable rows={rankings[active]} />
    </PageShell>
  );
}
