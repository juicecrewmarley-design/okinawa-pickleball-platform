"use client";

import { FormEvent, useEffect, useState } from "react";
import Link from "next/link";
import { CheckCircle2, Loader2, UserPlus } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { QrCodeCard } from "@/components/QrCodeCard";
import { areaLabels } from "@/lib/labels";
import { generateMemberId } from "@/lib/member";
import { isSupabaseConfigured, supabase } from "@/lib/supabase";
import type { Gender, MemberArea, MemberProfile } from "@/types/domain";

const areaOptions: MemberArea[] = ["south", "naha", "central", "miyako", "other"];
const genderOptions: { value: Gender; label: string }[] = [
  { value: "male", label: "男性" },
  { value: "female", label: "女性" },
  { value: "other", label: "その他" },
  { value: "no_answer", label: "回答しない" }
];

export default function RegisterPage() {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [createdMember, setCreatedMember] = useState<MemberProfile | null>(null);
  const [memberId, setMemberId] = useState("");

  useEffect(() => {
    setMemberId(generateMemberId());
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setMessage("");

    const formData = new FormData(event.currentTarget);
    const email = String(formData.get("email"));
    const password = String(formData.get("password"));
    const issuedMemberId = memberId || generateMemberId();
    const profile: MemberProfile = {
      id: "local-preview",
      memberId: issuedMemberId,
      fullName: String(formData.get("fullName")),
      furigana: String(formData.get("furigana")),
      gender: String(formData.get("gender")) as Gender,
      birthDate: String(formData.get("birthDate")),
      phone: String(formData.get("phone")),
      email,
      area: String(formData.get("area")) as MemberArea,
      role: "member",
      opr: 0,
      ranking: 0
    };

    try {
      if (isSupabaseConfigured && supabase) {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              full_name: profile.fullName,
              furigana: profile.furigana,
              gender: profile.gender,
              birth_date: profile.birthDate,
              phone: profile.phone,
              area: profile.area,
              member_id: profile.memberId
            }
          }
        });

        if (error) throw error;

        if (data.user && data.session) {
          const { error: profileError } = await supabase.from("profiles").upsert({
            id: data.user.id,
            member_id: profile.memberId,
            full_name: profile.fullName,
            furigana: profile.furigana,
            gender: profile.gender,
            birth_date: profile.birthDate || null,
            phone: profile.phone,
            email: profile.email,
            area: profile.area,
            role: "member"
          }, {
            onConflict: "id"
          });

          if (profileError) throw profileError;
        }

        setMessage("登録しました。確認メールが届く場合は、メール内のリンクを開いてください。");
      } else {
        window.localStorage.setItem("opba-demo-member", JSON.stringify(profile));
        setMessage("Supabase未設定のため、プレビュー用会員として保存しました。");
      }

      setCreatedMember(profile);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "登録中にエラーが発生しました。");
    } finally {
      setLoading(false);
    }
  }

  return (
    <PageShell
      eyebrow="Member Registration"
      title="会員登録"
      description="氏名、ふりがな、連絡先、所属エリアを登録し、会員IDとQRコード会員証を発行します。"
    >
      <div className="grid gap-6 lg:grid-cols-[1fr_0.9fr]">
        <form onSubmit={handleSubmit} className="rounded-lg border border-ocean-100 bg-white p-5 shadow-soft sm:p-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              氏名
              <input required name="fullName" className="focus-ring rounded-md border border-ocean-100 px-3 py-3" placeholder="沖縄 花子" />
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              ふりがな
              <input required name="furigana" className="focus-ring rounded-md border border-ocean-100 px-3 py-3" placeholder="おきなわ はなこ" />
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              性別
              <select required name="gender" className="focus-ring rounded-md border border-ocean-100 px-3 py-3">
                {genderOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              生年月日
              <input name="birthDate" type="date" className="focus-ring rounded-md border border-ocean-100 px-3 py-3" />
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              電話番号
              <input name="phone" type="tel" className="focus-ring rounded-md border border-ocean-100 px-3 py-3" placeholder="090-0000-0000" />
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              所属エリア
              <select required name="area" className="focus-ring rounded-md border border-ocean-100 px-3 py-3">
                {areaOptions.map((area) => (
                  <option key={area} value={area}>
                    {areaLabels[area]}
                  </option>
                ))}
              </select>
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              メールアドレス
              <input required name="email" type="email" className="focus-ring rounded-md border border-ocean-100 px-3 py-3" placeholder="member@example.com" />
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              パスワード
              <input required name="password" type="password" minLength={8} className="focus-ring rounded-md border border-ocean-100 px-3 py-3" placeholder="8文字以上" />
            </label>
          </div>

          <div className="mt-5 rounded-md bg-ocean-50 p-4">
            <p className="text-sm font-bold text-ocean-700">自動発行される会員ID</p>
            <p className="mt-1 text-2xl font-black text-ink">{memberId}</p>
          </div>

          {message ? (
            <p className="mt-4 flex items-center gap-2 rounded-md bg-palm-100 px-4 py-3 text-sm font-bold text-palm-700">
              <CheckCircle2 className="size-5" aria-hidden="true" />
              {message}
            </p>
          ) : null}

          <button
            type="submit"
            disabled={loading}
            className="focus-ring mt-5 inline-flex w-full items-center justify-center gap-2 rounded-md bg-ink px-5 py-3 font-black text-white transition hover:bg-ocean-700 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {loading ? <Loader2 className="size-5 animate-spin" aria-hidden="true" /> : <UserPlus className="size-5" aria-hidden="true" />}
            会員登録する
          </button>
          <p className="mt-4 text-center text-sm text-slate-600">
            登録済みの方は{" "}
            <Link href="/login" className="font-black text-ocean-700">
              ログイン
            </Link>
          </p>
        </form>

        <div className="space-y-4">
          {createdMember ? (
            <QrCodeCard member={createdMember} />
          ) : (
            <div className="rounded-lg border border-ocean-100 bg-white p-6 shadow-soft">
              <h2 className="text-xl font-black">登録後の表示</h2>
              <p className="mt-3 text-sm leading-7 text-slate-600">
                登録完了後、この場所にQRコード付き会員証のプレビューが表示されます。大会受付ではこのQRを提示する想定です。
              </p>
            </div>
          )}
          <div className="rounded-lg bg-coral-100 p-5 text-coral-600">
            <p className="font-black">MVPメモ</p>
            <p className="mt-2 text-sm leading-6">
              Supabase未設定時はブラウザ内にプレビュー保存します。本番運用ではSupabase Authとprofilesテーブルに保存します。
            </p>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
