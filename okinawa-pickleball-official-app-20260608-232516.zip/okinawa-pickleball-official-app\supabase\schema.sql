create extension if not exists "pgcrypto";

create type public.member_role as enum ('member', 'admin', 'sponsor');
create type public.member_area as enum ('south', 'naha', 'central', 'miyako', 'other');
create type public.gender_type as enum ('male', 'female', 'other', 'no_answer');
create type public.tournament_status as enum ('draft', 'open', 'closed', 'finished');
create type public.entry_status as enum ('pending', 'confirmed', 'cancelled');
create type public.notice_type as enum ('event', 'tournament', 'practice', 'association');
create type public.sponsor_rank as enum ('platinum', 'gold', 'silver', 'bronze', 'supporter');
create type public.opr_category as enum ('mens', 'womens', 'mixed', 'overall');

create sequence if not exists public.member_id_sequence start 1001;

create or replace function public.next_member_id()
returns text
language sql
as $$
  select 'OPBA-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('public.member_id_sequence')::text, 5, '0');
$$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  member_id text unique not null default public.next_member_id(),
  full_name text not null,
  furigana text not null,
  gender public.gender_type not null default 'no_answer',
  birth_date date,
  phone text,
  email text not null unique,
  area public.member_area not null default 'other',
  role public.member_role not null default 'member',
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tournaments (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null,
  venue text not null,
  start_at timestamptz not null,
  end_at timestamptz,
  entry_deadline timestamptz,
  fee_yen integer not null default 0,
  capacity integer,
  categories text[] not null default array[]::text[],
  status public.tournament_status not null default 'draft',
  image_url text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tournament_entries (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  category text not null,
  pair_or_team_name text not null,
  status public.entry_status not null default 'pending',
  note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tournament_id, user_id, category)
);

create table if not exists public.match_results (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  category text not null,
  round_name text,
  winner_entry_id uuid references public.tournament_entries(id),
  loser_entry_id uuid references public.tournament_entries(id),
  score text,
  placement integer,
  recorded_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.opr_points (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  tournament_id uuid references public.tournaments(id) on delete set null,
  season_year integer not null default extract(year from now())::integer,
  category public.opr_category not null,
  participation_points integer not null default 0,
  win_points integer not null default 0,
  placement_points integer not null default 0,
  total_points integer generated always as (participation_points + win_points + placement_points) stored,
  memo text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.notices (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  type public.notice_type not null default 'association',
  published_at timestamptz not null default now(),
  is_published boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.sponsors (
  id uuid primary key default gen_random_uuid(),
  company_name text not null,
  logo_url text,
  description text not null,
  website_url text,
  rank public.sponsor_rank not null default 'supporter',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.sponsor_contacts (
  id uuid primary key default gen_random_uuid(),
  sponsor_id uuid not null references public.sponsors(id) on delete cascade,
  contact_name text,
  email text,
  phone text,
  created_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger set_profiles_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

create trigger set_tournaments_updated_at
before update on public.tournaments
for each row execute function public.set_updated_at();

create trigger set_entries_updated_at
before update on public.tournament_entries
for each row execute function public.set_updated_at();

create trigger set_sponsors_updated_at
before update on public.sponsors
for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (
    id,
    member_id,
    full_name,
    furigana,
    gender,
    birth_date,
    phone,
    email,
    area,
    role
  )
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data ->> 'member_id', ''), public.next_member_id()),
    coalesce(nullif(new.raw_user_meta_data ->> 'full_name', ''), split_part(new.email, '@', 1)),
    coalesce(nullif(new.raw_user_meta_data ->> 'furigana', ''), ''),
    coalesce(nullif(new.raw_user_meta_data ->> 'gender', ''), 'no_answer')::public.gender_type,
    nullif(new.raw_user_meta_data ->> 'birth_date', '')::date,
    nullif(new.raw_user_meta_data ->> 'phone', ''),
    new.email,
    coalesce(nullif(new.raw_user_meta_data ->> 'area', ''), 'other')::public.member_area,
    'member'
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles
    where id = auth.uid()
      and role = 'admin'
  );
$$;

create or replace view public.annual_rankings as
select
  p.id as user_id,
  p.member_id,
  p.full_name,
  p.area,
  op.season_year,
  op.category,
  sum(op.total_points)::integer as total_points,
  rank() over (
    partition by op.season_year, op.category
    order by sum(op.total_points) desc, p.full_name asc
  ) as rank
from public.opr_points op
join public.profiles p on p.id = op.user_id
group by p.id, p.member_id, p.full_name, p.area, op.season_year, op.category;

alter table public.profiles enable row level security;
alter table public.tournaments enable row level security;
alter table public.tournament_entries enable row level security;
alter table public.match_results enable row level security;
alter table public.opr_points enable row level security;
alter table public.notices enable row level security;
alter table public.sponsors enable row level security;
alter table public.sponsor_contacts enable row level security;

create policy "profiles select own or admin"
on public.profiles for select
using (id = auth.uid() or public.is_admin());

create policy "profiles insert own"
on public.profiles for insert
with check (id = auth.uid());

create policy "profiles update own or admin"
on public.profiles for update
using (id = auth.uid() or public.is_admin())
with check (id = auth.uid() or public.is_admin());

create policy "tournaments public select"
on public.tournaments for select
using (status in ('open', 'closed', 'finished') or public.is_admin());

create policy "tournaments admin write"
on public.tournaments for all
using (public.is_admin())
with check (public.is_admin());

create policy "entries select own or admin"
on public.tournament_entries for select
using (user_id = auth.uid() or public.is_admin());

create policy "entries insert own"
on public.tournament_entries for insert
with check (user_id = auth.uid());

create policy "entries update own pending or admin"
on public.tournament_entries for update
using (user_id = auth.uid() or public.is_admin())
with check (user_id = auth.uid() or public.is_admin());

create policy "match results public select"
on public.match_results for select
using (true);

create policy "match results admin write"
on public.match_results for all
using (public.is_admin())
with check (public.is_admin());

create policy "opr points public select"
on public.opr_points for select
using (true);

create policy "opr points admin write"
on public.opr_points for all
using (public.is_admin())
with check (public.is_admin());

create policy "notices public select"
on public.notices for select
using (is_published = true or public.is_admin());

create policy "notices admin write"
on public.notices for all
using (public.is_admin())
with check (public.is_admin());

create policy "sponsors public select"
on public.sponsors for select
using (is_active = true or public.is_admin());

create policy "sponsors admin write"
on public.sponsors for all
using (public.is_admin())
with check (public.is_admin());

create policy "sponsor contacts admin only"
on public.sponsor_contacts for all
using (public.is_admin())
with check (public.is_admin());
