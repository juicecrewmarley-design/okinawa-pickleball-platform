import type { MemberProfile, Notice, RankingCategory, RankingRow, Sponsor, Tournament, TournamentEntry } from "@/types/domain";

export const mockMember: MemberProfile = {
  id: "demo-member",
  memberId: "OPBA-2026-01001",
  fullName: "沖縄 花子",
  furigana: "おきなわ はなこ",
  gender: "female",
  birthDate: "1992-07-16",
  phone: "090-0000-0000",
  email: "hanako@example.com",
  area: "naha",
  role: "member",
  opr: 1280,
  ranking: 12
};

export const tournaments: Tournament[] = [
  {
    id: "okinawa-open-2026",
    title: "沖縄オープン ピックルボールカップ 2026",
    description: "県内外のプレイヤーが参加できる年間ランキング対象大会です。",
    venue: "沖縄県総合運動公園 レクリエーションドーム",
    startAt: "2026-08-22T09:00:00+09:00",
    entryDeadline: "2026-08-10T23:59:00+09:00",
    feeYen: 3000,
    capacity: 160,
    categories: ["男子ダブルス", "女子ダブルス", "ミックス", "初心者", "150+", "200+"],
    status: "open"
  },
  {
    id: "naha-summer-league",
    title: "那覇サマーリーグ",
    description: "初心者から中級者まで参加しやすいリーグ形式の大会です。",
    venue: "那覇市民体育館",
    startAt: "2026-07-12T10:00:00+09:00",
    entryDeadline: "2026-07-01T23:59:00+09:00",
    feeYen: 2000,
    capacity: 80,
    categories: ["ミックス", "初心者", "150+"],
    status: "open"
  },
  {
    id: "miyako-island-cup",
    title: "宮古島カップ",
    description: "宮古エリアの交流促進を目的にした地域大会です。",
    venue: "宮古島市総合体育館",
    startAt: "2026-09-20T09:30:00+09:00",
    entryDeadline: "2026-09-05T23:59:00+09:00",
    feeYen: 2500,
    capacity: 96,
    categories: ["男子ダブルス", "女子ダブルス", "ミックス", "200+"],
    status: "open"
  }
];

export const entries: TournamentEntry[] = [
  {
    id: "entry-1",
    tournamentId: "okinawa-open-2026",
    memberId: "OPBA-2026-01001",
    memberName: "沖縄 花子",
    category: "ミックス",
    pairOrTeamName: "チーム美ら海",
    status: "confirmed",
    createdAt: "2026-06-01"
  },
  {
    id: "entry-2",
    tournamentId: "naha-summer-league",
    memberId: "OPBA-2026-01008",
    memberName: "宮城 太郎",
    category: "初心者",
    pairOrTeamName: "那覇スマッシュ",
    status: "pending",
    createdAt: "2026-06-04"
  }
];

export const rankings: Record<RankingCategory, RankingRow[]> = {
  mens: [
    { rank: 1, memberId: "OPBA-2026-01008", fullName: "宮城 太郎", area: "central", points: 1580, wins: 18 },
    { rank: 2, memberId: "OPBA-2026-01013", fullName: "比嘉 勇人", area: "south", points: 1495, wins: 16 },
    { rank: 3, memberId: "OPBA-2026-01021", fullName: "上原 健", area: "naha", points: 1410, wins: 14 }
  ],
  womens: [
    { rank: 1, memberId: "OPBA-2026-01001", fullName: "沖縄 花子", area: "naha", points: 1280, wins: 12 },
    { rank: 2, memberId: "OPBA-2026-01019", fullName: "島袋 美咲", area: "miyako", points: 1210, wins: 11 },
    { rank: 3, memberId: "OPBA-2026-01024", fullName: "仲村 優", area: "central", points: 1175, wins: 10 }
  ],
  mixed: [
    { rank: 1, memberId: "TEAM-CHURA", fullName: "チーム美ら海", area: "naha", points: 1760, wins: 20 },
    { rank: 2, memberId: "TEAM-SUN", fullName: "サンライズ沖縄", area: "south", points: 1605, wins: 17 },
    { rank: 3, memberId: "TEAM-MIYAKO", fullName: "宮古ブルー", area: "miyako", points: 1515, wins: 15 }
  ],
  overall: [
    { rank: 1, memberId: "OPBA-2026-01008", fullName: "宮城 太郎", area: "central", points: 2120, wins: 24 },
    { rank: 2, memberId: "OPBA-2026-01001", fullName: "沖縄 花子", area: "naha", points: 2040, wins: 22 },
    { rank: 3, memberId: "OPBA-2026-01013", fullName: "比嘉 勇人", area: "south", points: 1960, wins: 21 }
  ]
};

export const notices: Notice[] = [
  {
    id: "notice-1",
    title: "初心者向け体験会を毎月開催します",
    body: "那覇・中部・南部で体験会を開催。ラケットの貸出もあります。",
    type: "practice",
    publishedAt: "2026-06-03"
  },
  {
    id: "notice-2",
    title: "沖縄オープンのエントリー受付を開始しました",
    body: "男子、女子、ミックス、初心者、年齢合計カテゴリを受付中です。",
    type: "tournament",
    publishedAt: "2026-06-01"
  },
  {
    id: "notice-3",
    title: "協賛企業の募集を開始しました",
    body: "県内スポーツ振興と大会運営を一緒に支える企業を募集しています。",
    type: "association",
    publishedAt: "2026-05-28"
  }
];

export const sponsors: Sponsor[] = [
  {
    id: "sponsor-1",
    companyName: "琉球スポーツラボ",
    description: "県内スポーツイベントの企画・運営を支援する地域密着企業です。",
    websiteUrl: "https://example.com",
    rank: "platinum",
    logoLabel: "RSL"
  },
  {
    id: "sponsor-2",
    companyName: "美ら海ウェルネス",
    description: "健康づくりと地域交流を応援するウェルネスブランドです。",
    websiteUrl: "https://example.com",
    rank: "gold",
    logoLabel: "CW"
  },
  {
    id: "sponsor-3",
    companyName: "宮古アイランドツアーズ",
    description: "離島大会や交流イベントの移動・滞在を支援します。",
    websiteUrl: "https://example.com",
    rank: "silver",
    logoLabel: "MIT"
  }
];
