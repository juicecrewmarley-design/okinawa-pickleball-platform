import type { MemberProfile } from "@/types/domain";

export function generateMemberId() {
  const year = new Date().getFullYear();
  const random = Math.floor(10000 + Math.random() * 90000);
  return `OPBA-${year}-${random}`;
}

export function buildMemberCardPayload(member: Pick<MemberProfile, "memberId" | "fullName" | "area">) {
  return JSON.stringify({
    issuer: "Okinawa Pickleball Association",
    memberId: member.memberId,
    name: member.fullName,
    area: member.area,
    issuedAt: new Date().toISOString()
  });
}

export function formatYen(value: number) {
  return new Intl.NumberFormat("ja-JP", {
    style: "currency",
    currency: "JPY",
    maximumFractionDigits: 0
  }).format(value);
}
