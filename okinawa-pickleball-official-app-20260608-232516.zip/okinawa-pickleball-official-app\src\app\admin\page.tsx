"use client";

import { FormEvent, useState } from "react";
import {
  Bell,
  Building2,
  CalendarPlus,
  ClipboardList,
  Medal,
  Save,
  Shield,
  Trophy,
  Users
} from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { areaLabels } from "@/lib/labels";
import { entries, mockMember, tournaments } from "@/lib/mock-data";
import { isSupabaseConfigured, supabase } from "@/lib/supabase";

type AdminTab = "members" | "tournaments" | "entries" | "results" | "notices" | "sponsors";

const tabs: { id: AdminTab; label: string; icon: typeof Users }[] = [
  { id: "members", label: "会員", icon: Users },
  { id: "tournaments", label: "大会作成", icon: CalendarPlus },
  { id: "entries", label: "参加者", icon: ClipboardList },
  { id: "results", label: "結果・OPR", icon: Trophy },
  { id: "notices", label: "お知らせ", icon: Bell },
  { id: "sponsors", label: "協賛企業", icon: Building2 }
];

export default function AdminPage() {
  const [active, setActive] = useState<AdminTab>("members");
  const [message, setMessage] = useState("");

  async function handleTournamentSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("");

    const formData = new FormData(event.currentTarget);
    const payload = {
      title: String(formData.get("title")),
      description: String(formData.get("description")),
      venue: String(formData.get("venue")),
      start_at: String(formData.get("startAt")),
      entry_deadline: String(formData.get("entryDeadline")),
      fee_yen: Number(formData.get("feeYen")),
      capacity: Number(formData.get("capacity")),
      categories: String(formData.get("categories"))
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean),
      status: "open"
    };

    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.from("tournaments").insert(payload);
      setMessage(error ? error.message : "大会を作成しました。");
    } else {
      setMessage("プレビュー環境のため、大会作成フォームの入力確認のみ完了しました。");
    }
  }

  async function handleNoticeSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const payload = {
      title: String(formData.get("title")),
      body: String(formData.get("body")),
      type: String(formData.get("type")),
      is_published: true
    };

    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.from("notices").insert(payload);
      setMessage(error ? error.message : "お知らせを投稿しました。");
    } else {
      setMessage("プレビュー環境のため、お知らせ投稿フォームの入力確認のみ完了しました。");
    }
  }

  async function handleSponsorSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const payload = {
      company_name: String(formData.get("companyName")),
      description: String(formData.get("description")),
      website_url: String(formData.get("websiteUrl")),
      rank: String(formData.get("rank")),
      is_active: true
    };

    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.from("sponsors").insert(payload);
      setMessage(error ? error.message : "協賛企業を登録しました。");
    } else {
      setMessage("プレビュー環境のため、協賛企業登録フォームの入力確認のみ完了しました。");
    }
  }

  function handleResultSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("試合結果とOPRポイントの入力内容を受け付けました。Supabase接続後はmatch_resultsとopr_pointsへ保存します。");
  }

  return (
    <PageShell
      eyebrow="Admin"
      title="管理者画面"
      description="会員一覧、大会作成、参加者一覧、試合結果入力、OPR付与、お知らせ投稿、協賛企業情報登録を行います。"
    >
      <div className="mb-5 flex items-center gap-3 rounded-lg bg-ink p-4 text-white shadow-soft">
        <Shield className="size-6 text-coral-500" aria-hidden="true" />
        <p className="text-sm font-bold leading-6">
          本番ではSupabase Authとprofiles.roleで管理者権限を確認します。RLSにより管理者だけが書き込みできます。
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[230px_1fr]">
        <nav className="flex gap-2 overflow-x-auto lg:block lg:space-y-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActive(tab.id)}
                className={`focus-ring flex shrink-0 items-center gap-2 rounded-md px-4 py-3 text-sm font-black lg:w-full ${
                  active === tab.id ? "bg-ink text-white shadow-soft" : "bg-white text-ink shadow hover:bg-ocean-50"
                }`}
              >
                <Icon className="size-4" aria-hidden="true" />
                {tab.label}
              </button>
            );
          })}
        </nav>

        <section className="rounded-lg border border-ocean-100 bg-white p-5 shadow-soft sm:p-6">
          {message ? <p className="mb-5 rounded-md bg-palm-100 px-4 py-3 text-sm font-bold text-palm-700">{message}</p> : null}

          {active === "members" ? (
            <div>
              <h2 className="text-2xl font-black">会員一覧</h2>
              <div className="mt-5 overflow-x-auto">
                <table className="w-full min-w-[720px] text-left text-sm">
                  <thead className="bg-ocean-50 text-xs uppercase tracking-[0.16em] text-ocean-700">
                    <tr>
                      <th className="px-4 py-3">会員ID</th>
                      <th className="px-4 py-3">氏名</th>
                      <th className="px-4 py-3">エリア</th>
                      <th className="px-4 py-3">メール</th>
                      <th className="px-4 py-3">OPR</th>
                      <th className="px-4 py-3">権限</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ocean-50">
                    {[mockMember].map((member) => (
                      <tr key={member.memberId}>
                        <td className="px-4 py-4 font-bold text-slate-600">{member.memberId}</td>
                        <td className="px-4 py-4 font-black text-ink">{member.fullName}</td>
                        <td className="px-4 py-4">{areaLabels[member.area]}</td>
                        <td className="px-4 py-4">{member.email}</td>
                        <td className="px-4 py-4 font-black text-palm-700">{member.opr}</td>
                        <td className="px-4 py-4">{member.role}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : null}

          {active === "tournaments" ? (
            <form onSubmit={handleTournamentSubmit}>
              <h2 className="text-2xl font-black">大会作成</h2>
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <AdminInput name="title" label="大会名" placeholder="沖縄オープン 2026" required />
                <AdminInput name="venue" label="会場" placeholder="沖縄県総合運動公園" required />
                <AdminInput name="startAt" label="開催日時" type="datetime-local" required />
                <AdminInput name="entryDeadline" label="申込締切" type="datetime-local" required />
                <AdminInput name="feeYen" label="参加費" type="number" placeholder="3000" required />
                <AdminInput name="capacity" label="定員" type="number" placeholder="160" required />
                <label className="grid gap-2 text-sm font-bold text-slate-700 sm:col-span-2">
                  カテゴリ
                  <input required name="categories" className="focus-ring rounded-md border border-ocean-100 px-3 py-3" placeholder="男子ダブルス, 女子ダブルス, ミックス, 初心者, 150+, 200+" />
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700 sm:col-span-2">
                  説明
                  <textarea required name="description" rows={4} className="focus-ring rounded-md border border-ocean-100 px-3 py-3" placeholder="大会概要、対象者、持ち物など" />
                </label>
              </div>
              <SaveButton label="大会を保存" />
            </form>
          ) : null}

          {active === "entries" ? (
            <div>
              <h2 className="text-2xl font-black">大会参加者一覧</h2>
              <div className="mt-5 grid gap-4">
                {entries.map((entry) => {
                  const tournament = tournaments.find((item) => item.id === entry.tournamentId);
                  return (
                    <article key={entry.id} className="rounded-md bg-ocean-50 p-4">
                      <p className="font-black text-ink">{entry.memberName}</p>
                      <p className="mt-1 text-sm text-slate-600">{entry.memberId}</p>
                      <p className="mt-2 text-sm">
                        {tournament?.title} / {entry.category} / {entry.pairOrTeamName}
                      </p>
                      <span className="mt-3 inline-flex rounded-full bg-white px-3 py-1 text-xs font-black text-ocean-700">
                        {entry.status}
                      </span>
                    </article>
                  );
                })}
              </div>
            </div>
          ) : null}

          {active === "results" ? (
            <form onSubmit={handleResultSubmit}>
              <h2 className="text-2xl font-black">試合結果入力・ポイント付与</h2>
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  大会
                  <select name="tournament" className="focus-ring rounded-md border border-ocean-100 px-3 py-3">
                    {tournaments.map((tournament) => (
                      <option key={tournament.id}>{tournament.title}</option>
                    ))}
                  </select>
                </label>
                <AdminInput name="category" label="カテゴリ" placeholder="ミックス" required />
                <AdminInput name="winner" label="勝者エントリー" placeholder="チーム美ら海" required />
                <AdminInput name="score" label="スコア" placeholder="11-8, 11-7" />
                <AdminInput name="participationPoints" label="参加ポイント" type="number" placeholder="20" required />
                <AdminInput name="winPoints" label="勝利ポイント" type="number" placeholder="50" required />
                <AdminInput name="placementPoints" label="順位ポイント" type="number" placeholder="100" required />
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  種目
                  <select name="oprCategory" className="focus-ring rounded-md border border-ocean-100 px-3 py-3">
                    <option value="mens">男子</option>
                    <option value="womens">女子</option>
                    <option value="mixed">ミックス</option>
                    <option value="overall">総合</option>
                  </select>
                </label>
              </div>
              <SaveButton label="結果とOPRを保存" icon={<Medal className="size-5" aria-hidden="true" />} />
            </form>
          ) : null}

          {active === "notices" ? (
            <form onSubmit={handleNoticeSubmit}>
              <h2 className="text-2xl font-black">お知らせ投稿</h2>
              <div className="mt-5 grid gap-4">
                <AdminInput name="title" label="タイトル" placeholder="初心者向け体験会を開催します" required />
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  種別
                  <select name="type" className="focus-ring rounded-md border border-ocean-100 px-3 py-3">
                    <option value="event">イベント案内</option>
                    <option value="tournament">大会案内</option>
                    <option value="practice">練習会案内</option>
                    <option value="association">協会からのお知らせ</option>
                  </select>
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  本文
                  <textarea required name="body" rows={5} className="focus-ring rounded-md border border-ocean-100 px-3 py-3" />
                </label>
              </div>
              <SaveButton label="お知らせを投稿" />
            </form>
          ) : null}

          {active === "sponsors" ? (
            <form onSubmit={handleSponsorSubmit}>
              <h2 className="text-2xl font-black">協賛企業情報登録</h2>
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <AdminInput name="companyName" label="企業名" placeholder="琉球スポーツラボ" required />
                <AdminInput name="websiteUrl" label="リンク" type="url" placeholder="https://example.com" />
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  協賛ランク
                  <select name="rank" className="focus-ring rounded-md border border-ocean-100 px-3 py-3">
                    <option value="platinum">プラチナ</option>
                    <option value="gold">ゴールド</option>
                    <option value="silver">シルバー</option>
                    <option value="bronze">ブロンズ</option>
                    <option value="supporter">サポーター</option>
                  </select>
                </label>
                <AdminInput name="logoUrl" label="ロゴURL" type="url" placeholder="https://..." />
                <label className="grid gap-2 text-sm font-bold text-slate-700 sm:col-span-2">
                  紹介文
                  <textarea required name="description" rows={4} className="focus-ring rounded-md border border-ocean-100 px-3 py-3" />
                </label>
              </div>
              <SaveButton label="協賛企業を登録" />
            </form>
          ) : null}
        </section>
      </div>
    </PageShell>
  );
}

function AdminInput({
  label,
  name,
  type = "text",
  placeholder,
  required
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <label className="grid gap-2 text-sm font-bold text-slate-700">
      {label}
      <input
        required={required}
        name={name}
        type={type}
        className="focus-ring rounded-md border border-ocean-100 px-3 py-3"
        placeholder={placeholder}
      />
    </label>
  );
}

function SaveButton({ label, icon }: { label: string; icon?: React.ReactNode }) {
  return (
    <button className="focus-ring mt-5 inline-flex w-full items-center justify-center gap-2 rounded-md bg-ink px-5 py-3 font-black text-white transition hover:bg-ocean-700">
      {icon ?? <Save className="size-5" aria-hidden="true" />}
      {label}
    </button>
  );
}
