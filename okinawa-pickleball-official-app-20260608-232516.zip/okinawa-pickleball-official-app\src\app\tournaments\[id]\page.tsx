"use client";

import { FormEvent, useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { CalendarDays, CheckCircle2, Loader2, MapPin, Trophy, Users } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { StatusBadge } from "@/components/StatusBadge";
import { formatYen } from "@/lib/member";
import { tournaments } from "@/lib/mock-data";
import { isSupabaseConfigured, supabase } from "@/lib/supabase";

export default function TournamentDetailPage() {
  const params = useParams<{ id: string }>();
  const tournament = useMemo(() => tournaments.find((item) => item.id === params.id), [params.id]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!tournament) return;

    setLoading(true);
    setMessage("");

    const formData = new FormData(event.currentTarget);
    const category = String(formData.get("category"));
    const pairOrTeamName = String(formData.get("pairOrTeamName"));

    try {
      if (isSupabaseConfigured && supabase) {
        const { data: sessionData } = await supabase.auth.getSession();
        const userId = sessionData.session?.user.id;

        if (!userId) {
          setMessage("エントリーするにはログインしてください。");
          return;
        }

        const { error } = await supabase.from("tournament_entries").insert({
          tournament_id: tournament.id,
          user_id: userId,
          category,
          pair_or_team_name: pairOrTeamName,
          status: "pending"
        });

        if (error) throw error;
      }

      setMessage(`${category} / ${pairOrTeamName}でエントリーを受け付けました。`);
      event.currentTarget.reset();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "エントリー中にエラーが発生しました。");
    } finally {
      setLoading(false);
    }
  }

  if (!tournament) {
    return (
      <PageShell title="大会が見つかりません">
        <Link className="font-black text-ocean-700" href="/tournaments">
          大会一覧へ戻る
        </Link>
      </PageShell>
    );
  }

  return (
    <PageShell
      eyebrow="Tournament Entry"
      title={tournament.title}
      description={tournament.description}
    >
      <div className="grid gap-6 lg:grid-cols-[1fr_0.85fr]">
        <section className="rounded-lg border border-ocean-100 bg-white p-5 shadow-soft sm:p-6">
          <div className="flex flex-wrap items-center gap-3">
            <StatusBadge status={tournament.status} />
            <span className="rounded-full bg-coral-100 px-3 py-1 text-sm font-black text-coral-600">
              {formatYen(tournament.feeYen)}
            </span>
          </div>
          <dl className="mt-6 grid gap-4 text-sm text-slate-700">
            <div className="flex items-center gap-3 rounded-md bg-ocean-50 p-4">
              <CalendarDays className="size-5 text-ocean-700" aria-hidden="true" />
              <span>{new Date(tournament.startAt).toLocaleString("ja-JP")}</span>
            </div>
            <div className="flex items-center gap-3 rounded-md bg-ocean-50 p-4">
              <MapPin className="size-5 text-ocean-700" aria-hidden="true" />
              <span>{tournament.venue}</span>
            </div>
            <div className="flex items-center gap-3 rounded-md bg-ocean-50 p-4">
              <Users className="size-5 text-ocean-700" aria-hidden="true" />
              <span>定員 {tournament.capacity}名 / 申込締切 {new Date(tournament.entryDeadline).toLocaleDateString("ja-JP")}</span>
            </div>
          </dl>

          <div className="mt-6">
            <h2 className="text-xl font-black">カテゴリ</h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {tournament.categories.map((category) => (
                <span key={category} className="rounded-full bg-palm-100 px-3 py-1 text-sm font-black text-palm-700">
                  {category}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-6 rounded-md bg-coral-100 p-4 text-coral-600">
            <p className="font-black">OPRポイント付与ルール</p>
            <p className="mt-2 text-sm leading-6">
              参加ポイント、勝利ポイント、順位ポイントを大会終了後に管理者が付与します。
            </p>
          </div>
        </section>

        <form onSubmit={handleSubmit} className="rounded-lg border border-ocean-100 bg-white p-5 shadow-soft sm:p-6">
          <div className="mb-5 flex items-center gap-3">
            <span className="grid size-11 place-items-center rounded-full bg-ocean-50 text-ocean-700">
              <Trophy className="size-5" aria-hidden="true" />
            </span>
            <div>
              <h2 className="text-xl font-black">エントリー</h2>
              <p className="text-sm text-slate-600">カテゴリとペア名またはチーム名を入力してください。</p>
            </div>
          </div>

          <label className="grid gap-2 text-sm font-bold text-slate-700">
            カテゴリ
            <select required name="category" className="focus-ring rounded-md border border-ocean-100 px-3 py-3">
              {tournament.categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </label>
          <label className="mt-4 grid gap-2 text-sm font-bold text-slate-700">
            ペア名またはチーム名
            <input required name="pairOrTeamName" className="focus-ring rounded-md border border-ocean-100 px-3 py-3" placeholder="例: チーム美ら海" />
          </label>
          {message ? (
            <p className="mt-4 flex items-center gap-2 rounded-md bg-palm-100 px-4 py-3 text-sm font-bold text-palm-700">
              <CheckCircle2 className="size-5" aria-hidden="true" />
              {message}
            </p>
          ) : null}
          <button
            disabled={loading || tournament.status !== "open"}
            className="focus-ring mt-5 inline-flex w-full items-center justify-center gap-2 rounded-md bg-ink px-5 py-3 font-black text-white transition hover:bg-ocean-700 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {loading ? <Loader2 className="size-5 animate-spin" aria-hidden="true" /> : <CheckCircle2 className="size-5" aria-hidden="true" />}
            エントリーする
          </button>
        </form>
      </div>
    </PageShell>
  );
}
