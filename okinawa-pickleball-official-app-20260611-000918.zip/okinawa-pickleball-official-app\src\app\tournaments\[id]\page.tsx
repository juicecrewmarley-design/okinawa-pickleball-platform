"use client";

import { FormEvent, useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { CalendarDays, CheckCircle2, Loader2, MapPin, Trophy, Users } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { StatusBadge } from "@/components/StatusBadge";
import { formatYen } from "@/lib/member";
import { tournaments } from "@/lib/mock-data";
import { isSupabaseConfigured, supabase } from "@/lib/supabase";
import { defaultTournamentCategoryConfig } from "@/lib/tournament-categories";

type EntryType = "doubles" | "team";

export default function TournamentDetailPage() {
  const params = useParams<{ id: string }>();
  const tournament = useMemo(() => tournaments.find((item) => item.id === params.id), [params.id]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [entryType, setEntryType] = useState<EntryType>("doubles");

  const categoryConfig = tournament?.categoryConfig ?? defaultTournamentCategoryConfig;

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!tournament) return;

    setLoading(true);
    setMessage("");

    const formData = new FormData(event.currentTarget);
    const pairOrTeamName = String(formData.get("pairOrTeamName"));
    const division = String(formData.get("division") ?? "");
    const doublesClass = String(formData.get("doublesClass") ?? "");
    const teamAgeCategory = String(formData.get("teamAgeCategory") ?? "");

    const partnerMemberId = String(formData.get("partnerMemberId") ?? "").trim();
    const partnerName = String(formData.get("partnerName") ?? "").trim();
    const teamMembers = [2, 3, 4].map((index) => ({
      memberId: String(formData.get(`teamMember${index}Id`) ?? "").trim(),
      name: String(formData.get(`teamMember${index}Name`) ?? "").trim()
    }));

    const category = entryType === "doubles" ? `${division} / ${doublesClass}` : `チーム戦 / ${teamAgeCategory}`;
    const isLinked =
      entryType === "doubles"
        ? Boolean(partnerMemberId && partnerName)
        : teamMembers.every((member) => member.memberId && member.name);
    const status = isLinked ? "confirmed" : "pending";
    const linkingStatus = isLinked ? "linked" : "waiting";

    try {
      if (isSupabaseConfigured && supabase) {
        const { data: sessionData } = await supabase.auth.getSession();
        const userId = sessionData.session?.user.id;

        if (!userId) {
          setMessage("エントリーするにはログインしてください。");
          return;
        }

        const { error } = await supabase.from("tournament_entries").insert({
          tournament_id: tournament.id,
          user_id: userId,
          category,
          pair_or_team_name: pairOrTeamName,
          entry_type: entryType,
          division: entryType === "doubles" ? division : "チーム戦",
          class_or_age_category: entryType === "doubles" ? doublesClass : teamAgeCategory,
          partner_member_id: entryType === "doubles" ? partnerMemberId : null,
          partner_name: entryType === "doubles" ? partnerName : null,
          team_members: entryType === "team" ? teamMembers : [],
          linking_status: linkingStatus,
          status
        });

        if (error) throw error;
      }

      setMessage(
        isLinked
          ? `${category} / ${pairOrTeamName} は紐づけ完了のため、エントリー確定になりました。`
          : `${category} / ${pairOrTeamName} は紐づけ待ちです。必要メンバーがそろうと確定できます。`
      );
      event.currentTarget.reset();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "エントリー中にエラーが発生しました。");
    } finally {
      setLoading(false);
    }
  }

  if (!tournament) {
    return (
      <PageShell title="大会が見つかりません">
        <Link className="font-black text-ocean-700" href="/tournaments">
          大会一覧へ戻る
        </Link>
      </PageShell>
    );
  }

  return (
    <PageShell eyebrow="Tournament Entry" title={tournament.title} description={tournament.description}>
      <div className="grid gap-6 lg:grid-cols-[1fr_0.85fr]">
        <section className="rounded-lg border border-ocean-100 bg-white p-5 shadow-soft sm:p-6">
          <div className="flex flex-wrap items-center gap-3">
            <StatusBadge status={tournament.status} />
            <span className="rounded-full bg-coral-100 px-3 py-1 text-sm font-black text-coral-600">
              {formatYen(tournament.feeYen)}
            </span>
          </div>
          <dl className="mt-6 grid gap-4 text-sm text-slate-700">
            <div className="flex items-center gap-3 rounded-md bg-ocean-50 p-4">
              <CalendarDays className="size-5 text-ocean-700" aria-hidden="true" />
              <span>{new Date(tournament.startAt).toLocaleString("ja-JP")}</span>
            </div>
            <div className="flex items-center gap-3 rounded-md bg-ocean-50 p-4">
              <MapPin className="size-5 text-ocean-700" aria-hidden="true" />
              <span>{tournament.venue}</span>
            </div>
            <div className="flex items-center gap-3 rounded-md bg-ocean-50 p-4">
              <Users className="size-5 text-ocean-700" aria-hidden="true" />
              <span>定員 {tournament.capacity}名 / 申込締切 {new Date(tournament.entryDeadline).toLocaleDateString("ja-JP")}</span>
            </div>
          </dl>

          <div className="mt-6">
            <h2 className="text-xl font-black">カテゴリ</h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {tournament.categories.map((category) => (
                <span key={category} className="rounded-full bg-palm-100 px-3 py-1 text-sm font-black text-palm-700">
                  {category}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-6 rounded-md bg-coral-100 p-4 text-coral-600">
            <p className="font-black">エントリー確定ルール</p>
            <p className="mt-2 text-sm leading-6">
              ダブルスはペア1名、チーム戦は合計4名のメンバーを紐づけます。必要人数がそろった時点でエントリー確定になります。
            </p>
          </div>
        </section>

        <form onSubmit={handleSubmit} className="rounded-lg border border-ocean-100 bg-white p-5 shadow-soft sm:p-6">
          <div className="mb-5 flex items-center gap-3">
            <span className="grid size-11 place-items-center rounded-full bg-ocean-50 text-ocean-700">
              <Trophy className="size-5" aria-hidden="true" />
            </span>
            <div>
              <h2 className="text-xl font-black">エントリー</h2>
              <p className="text-sm text-slate-600">種目を選び、ペアまたはチームメンバーを紐づけてください。</p>
            </div>
          </div>

          <div className="mb-4 grid grid-cols-2 gap-2 rounded-md bg-ocean-50 p-1">
            {(["doubles", "team"] as EntryType[]).map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setEntryType(type)}
                className={`focus-ring rounded-md px-3 py-3 text-sm font-black ${
                  entryType === type ? "bg-white text-ink shadow" : "text-slate-600"
                }`}
              >
                {type === "doubles" ? "ダブルス" : "チーム戦"}
              </button>
            ))}
          </div>

          {entryType === "doubles" ? (
            <div className="grid gap-4">
              <label className="grid gap-2 text-sm font-bold text-slate-700">
                選択枠
                <select required name="division" className="focus-ring rounded-md border border-ocean-100 px-3 py-3">
                  {categoryConfig.doubles.divisions.map((division) => (
                    <option key={division} value={division}>
                      {division}
                    </option>
                  ))}
                </select>
              </label>
              <label className="grid gap-2 text-sm font-bold text-slate-700">
                カテゴリ
                <select required name="doublesClass" className="focus-ring rounded-md border border-ocean-100 px-3 py-3">
                  {categoryConfig.doubles.classes.map((className) => (
                    <option key={className} value={className}>
                      {className}
                    </option>
                  ))}
                </select>
              </label>
              <AdminLikeInput name="pairOrTeamName" label="ペア名" placeholder="例: チーム美ら海" required />
              <AdminLikeInput name="partnerMemberId" label="ペアの会員ID" placeholder="例: OKP-0002" required />
              <AdminLikeInput name="partnerName" label="ペアの氏名" placeholder="例: 金城 直人" required />
            </div>
          ) : (
            <div className="grid gap-4">
              <label className="grid gap-2 text-sm font-bold text-slate-700">
                チーム戦カテゴリ
                <select required name="teamAgeCategory" className="focus-ring rounded-md border border-ocean-100 px-3 py-3">
                  {categoryConfig.team.ageCategories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </label>
              <AdminLikeInput name="pairOrTeamName" label="チーム名" placeholder="例: 那覇スマッシュ" required />
              {[2, 3, 4].map((index) => (
                <div key={index} className="grid gap-3 rounded-md bg-ocean-50 p-3 sm:grid-cols-2">
                  <AdminLikeInput name={`teamMember${index}Id`} label={`メンバー${index} 会員ID`} placeholder={`例: OKP-000${index}`} required />
                  <AdminLikeInput name={`teamMember${index}Name`} label={`メンバー${index} 氏名`} placeholder="氏名" required />
                </div>
              ))}
            </div>
          )}

          {message ? (
            <p className="mt-4 flex items-center gap-2 rounded-md bg-palm-100 px-4 py-3 text-sm font-bold text-palm-700">
              <CheckCircle2 className="size-5" aria-hidden="true" />
              {message}
            </p>
          ) : null}
          <button
            disabled={loading || tournament.status !== "open"}
            className="focus-ring mt-5 inline-flex w-full items-center justify-center gap-2 rounded-md bg-ink px-5 py-3 font-black text-white transition hover:bg-ocean-700 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {loading ? <Loader2 className="size-5 animate-spin" aria-hidden="true" /> : <CheckCircle2 className="size-5" aria-hidden="true" />}
            紐づけてエントリーする
          </button>
        </form>
      </div>
    </PageShell>
  );
}

function AdminLikeInput({
  label,
  name,
  placeholder,
  required
}: {
  label: string;
  name: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <label className="grid gap-2 text-sm font-bold text-slate-700">
      {label}
      <input required={required} name={name} className="focus-ring rounded-md border border-ocean-100 px-3 py-3" placeholder={placeholder} />
    </label>
  );
}
